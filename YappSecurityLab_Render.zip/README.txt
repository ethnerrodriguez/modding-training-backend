Yapp Security Lab 2 - Render Server
=====================================
Deploy as a Render Web Service.

The server intentionally has WEAK client-state validation. This is a controlled
training environment. It is not production security.

After deployment, copy the wss:// Render WebSocket URL into the game's Server box.

Important lesson:
The server currently accepts x/y/energy/score/coins/speed from the browser.
That is intentionally insecure. The next stage is to attack this LAB state,
identify the trust problem, then fix it by making the server authoritative.

Do not deploy this code for real users or use it against third-party services.
